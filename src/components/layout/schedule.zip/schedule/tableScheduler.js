import React, { useState } from "react";
import "./tableSchedule.css";

export const TableScheduler = () => {
  const subjects = [
    "Compiladores",
    "Titulación",
    "Ingenieria de SW I",
    "Inteligencia Artificial",
    "Etica",
    "Programacion Avanzada",
    "Control Automatizado",
    "Redes",
    "AD2",
  ];
  const days=[
    "Lunes","Martes","Miercoles","Jueves","Viernes"
  ];

  let [name, setname] = useState('');
  
  /* The handleChange() function to set a new state for input */
  const handleChange = (event) => {
    setname(event.target.value);
  }
const data=[{dia:"",hora:"",materia:""}];

  return (
    <>
      <div className="divMain">
        <div className="left">
          <table>
            {subjects.map((row, index) => (
              <tr key={index}>
                <td>
                  <div className="item" value={row}>
                    {" "}
                    {row}{" "}
                  </div>
                </td>
              </tr>
            ))}
          </table>
        </div>
        <div className="right">
          <table id="schedule">
            <tr >
              <td className="blank"></td>
              {days.map((row, index) => (
                <td className="title" id={row} key={index}> {row} </td>
              ))}
              
            </tr>
            <tr>
              <td className="time" id="hour1">
                7:30
              </td>
              <td className="drop" ></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
            </tr>
            <tr>
              <td className="time" id="hour2">
                8:30
              </td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
            </tr>
            <tr>
              <td className="time" id="hour3">
                9:30
              </td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
            </tr>
            <tr>
              <td className="time" id="hour4">
                10:30
              </td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
            </tr>
            <tr>
              <td className="time" id="hour5">
                11:30
              </td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
            </tr>
            <tr>
              <td className="time" id="hour6">
                12:30
              </td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
            </tr>
            <tr>
              <td className="time" id="hour7">
                13:30
              </td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
            </tr>
            <tr>
              <td className="time" id="hour8">
                14:30
              </td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
              <td className="drop"></td>
            </tr>
          </table>
          <div>
            <button id="b2">Guardar</button>
          </div>
        </div>
      </div>
    </>
  );
};
